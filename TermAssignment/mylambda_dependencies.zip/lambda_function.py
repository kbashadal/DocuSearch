import json
import os
import boto3
from flask import Flask, render_template, request, redirect, url_for, 
flash
from flask_login import LoginManager, login_user, login_required, 
current_user, logout_user
from werkzeug.utils import secure_filename
from botocore.exceptions import NoCredentialsError, ClientError

def lambda_handler(event, context):
    name = event['name']
    # TODO implement
    return {
        'statusCode': 200,
        'body': f'Hello, {name}!'
    }
